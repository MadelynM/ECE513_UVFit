#ifndef ACTIVITY_REPORTER_H
#define ACTIVITY_REPORTER_H

//-------------------------------------------------------------------

#include <AssetTracker.h>
#include "ActivityDetector.h"

//-------------------------------------------------------------------

class ActivityReporter {
   enum State { S_Wait, S_Publish, S_LedNotify };

private:
    int rate;

private:
    State state;
    int tick;
    int led;
    AssetTracker& gpsSensor;
    ActivityDetector& activityDetector;

public:
    ActivityReporter(AssetTracker &theTracker, ActivityDetector &theDetector);    
    void execute();
};

//-------------------------------------------------------------------

#endif