#ifndef ACTIVITY_DETECTOR_H
#define ACTIVITY_DETECTOR_H

#include <vector>
#include <AssetTracker.h>

using namespace std;

class ActivityDetector {
  enum State { S_Wait, S_Sample, S_Filter, S_Detected, S_WaitUntilReported, S_StopEverything };
  
  private:
    int rate;
    int samples;
    float threshold;
    
    int tick;
    int numSamp;
    State curState;
    
    vector<int> accelSamples;
    int sampleIndex;
    bool activityDetected;
    float avgMagnitude;
    AssetTracker& accelSensor;
    
  public: // MAM Make sure we actually need all of these.
    ActivityDetector(AssetTracker& theTracker, int rate, int samples, float threshold);
    bool isDetected();
    void setReported();
    void execute();
    bool amIStopped();
    void stopEverything();
    void carryOn();
};

#endif