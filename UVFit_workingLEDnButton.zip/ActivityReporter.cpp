//-------------------------------------------------------------------

#include "ActivityReporter.h"
#include <AssetTracker.h>

//-------------------------------------------------------------------

//#define DEBUG

//-------------------------------------------------------------------

ActivityReporter::ActivityReporter(AssetTracker &theTracker, 
                                   ActivityDetector &theDetector) :
    gpsSensor(theTracker), 
    activityDetector(theDetector)
{    
        
    tick = 0;
    state = S_Wait;
    led = D7; 
    pinMode(led, OUTPUT);
}

//-------------------------------------------------------------------

void ActivityReporter::execute() {
    String postData;

#ifdef DEBUG
    Serial.print("ActivityReporter SM: ");
    Serial.println(state);
#endif

    switch (state) {
        case ActivityReporter::S_Wait:
            tick = 0;
            digitalWrite(led, LOW);
            
            if (activityDetector.isDetected()) {
                state = ActivityReporter::S_Publish;
            }
            else {
                state = ActivityReporter::S_Wait;
            }
            break;

        case ActivityReporter::S_Publish:
            if (gpsSensor.gpsFix()) {
               postData = String::format("{ \"longitude\": \"%f\", \"latitude\": \"%f\" }", 
                                         gpsSensor.readLonDeg(), gpsSensor.readLatDeg());
            }
 //           else {
 //              postData = String::format("{ \"longitude\": \"%f\", \"latitude\": \"%f\" }", 
 //                                        -110.987420, 32.248820);
 //           }

            Serial.println(postData);
            Particle.publish("gps", postData);
            activityDetector.setReported();
            
            state = ActivityReporter::S_LedNotify;
            break;

        case ActivityReporter::S_LedNotify:
            digitalWrite(led, HIGH);
            ++tick;

            // Keep LED on for 2 seconds
            if (tick == 200) {
                state = ActivityReporter::S_Wait;
            }
            else {
                state = ActivityReporter::S_LedNotify;
            }
            break;
    }
}

//-------------------------------------------------------------------


