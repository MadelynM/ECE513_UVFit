#include "ActivityDetector.h"

ActivityDetector::ActivityDetector(AssetTracker& theTracker, 
                                   int rate,
                                   int samples,
                                   float threshold):
  accelSensor(theTracker),
  accelSamples(samples)
{
                this->rate = rate;
                this->samples = samples;
                this->threshold = threshold;
                tick=0;
                sampleIndex = 0;
                activityDetected = false;
                this->curState = S_Wait;
}

bool ActivityDetector::amIStopped()
{
    if(this->curState== S_StopEverything)
    { return true;}
    return false;
}

void ActivityDetector::carryOn()
{ this->curState = S_Wait; }

void ActivityDetector::stopEverything()
{ this->curState = S_StopEverything; }

void ActivityDetector::execute() 
{
    // MAM Need to replace with actual UVFit logic!
     switch (this->curState) 
     {
        case ActivityDetector::S_Wait:
            ++tick;
            sampleIndex = 0;

            if (tick == this->rate) {
                this->curState = ActivityDetector::S_Sample;
            }
            else {
                this->curState = ActivityDetector::S_Wait;
            }
            break;

        case ActivityDetector::S_Sample:
            tick = 0;
            accelSamples.at(sampleIndex) = accelSensor.readXYZmagnitude();
            sampleIndex++;
            
            if (sampleIndex == samples) {
                this->curState = ActivityDetector::S_Filter;
            }
            else {
                this->curState = ActivityDetector::S_Sample;
            }
            break;

        case ActivityDetector::S_Filter:
            avgMagnitude = 0.0;
            for (int i = 0; i < samples; ++i) {
                avgMagnitude += static_cast<float>(accelSamples.at(i));
            }
            avgMagnitude = avgMagnitude / samples;

            if (avgMagnitude > threshold) {
                this->curState = ActivityDetector::S_Detected;
            }
            else {
                this->curState = ActivityDetector::S_Wait;
            }
            break;

        case ActivityDetector::S_Detected:
            activityDetected = true;
            this->curState = ActivityDetector::S_WaitUntilReported;
            break;

        case ActivityDetector::S_WaitUntilReported:
            if (activityDetected == true) {
                this->curState = ActivityDetector::S_WaitUntilReported;
            }
            else {
                this->curState = ActivityDetector::S_Wait;
            }
            break;
    }
    Serial.println(this->curState);
    
}